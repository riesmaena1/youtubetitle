# youtube-title-automation

1. Open https://www.google.com/script/start/
2. Start scripting
3. press + on service then search Youtube V3 then add
4. edit all kode.gs with app.gs
5. edit your video ID
6. Test run then login with your youtube account
7. set cron job
8. dah kelar
